# My First Project > 2025-09-26 4:22pm
https://universe.roboflow.com/number4-rwy3h/my-first-project-pp0wx

Provided by a Roboflow user
License: CC BY 4.0

